package com.example.intent

import android.annotation.SuppressLint
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import com.example.intent.R.*

class MainActivity2 : AppCompatActivity() {
    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(layout.activity_main2)

        val bundle:Bundle?=intent.extras
        var msg=bundle?.getString("Hello")
        var tv=findViewById<TextView>(id.TV)
        tv.text=msg
        var b2=findViewById<Button>(id.A2B)
        var b3=findViewById<Button>(id.A3B)
        var et2 = findViewById<EditText>(id.ET2)
        b2.setOnClickListener {
            var intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
        }
        b3.setOnClickListener {
            var id = et2.text.toString()
            var intent = Intent(this, MainActivity3::class.java)

            intent.putExtra("Welcome", id)
            startActivity(intent)
        }

        }
    }
